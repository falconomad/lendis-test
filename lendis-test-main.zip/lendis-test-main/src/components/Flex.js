import styled from 'styled-components';
import { justifyContent } from 'styled-system';
import Box from '../components/Box';

const Flex = styled(Box)`
${justifyContent}
`;

Flex.propTypes = Box.propTypes;

Flex.defaultProps = {
  display: 'flex',
  alignItems: "center"
};

export default Flex;
