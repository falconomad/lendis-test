import React, { useContext } from 'react';
import { Container } from '../components/Grid';
import Box from '../components/Box';
import { CartContext } from '../App';
import Flex from '../components/Flex';
import Button from '../components/Button';

const Checkout = () => {
  const { items, removeItems } = useContext(
    CartContext
  );

  const total = () => {
    let sum = 0;
    items.forEach(element => {
        sum+=element.price;
    });
    return sum;
  }
  return (
    <Container>
      <Box textAlign="center">
        <h1>Checkout</h1>
        {
          items.map((element)=> {
            return <Flex key={element.id} justifyContent={"space-between"} paddingBottom={5}>
              <span>
                {element.name} * {element.count}
              </span>
              <Button data-testid={`checkout-remove-${element.id}`} variant={"warn"} onClick={()=> removeItems(element)}>
                Remove
              </Button>
            </Flex>
          })
        }
      </Box>
      <Box>
        <h2>
          Total
        </h2>
        <span data-testid={"total-price"}>
          {total()}$
        </span>
      </Box>

    </Container>
  );
};

export default Checkout;
