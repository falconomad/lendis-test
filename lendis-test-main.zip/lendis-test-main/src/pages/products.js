import React from 'react';
import ItemList from '../modules/items/ItemList';
import { Container } from '../components/Grid';
import Box from '../components/Box';

const Products = () => {
  return (
    <Container>
      <Box textAlign="center">
        <h1>Choose your Tees!</h1>
      </Box>
      <ItemList />
    </Container>
  );
};

export default Products;
