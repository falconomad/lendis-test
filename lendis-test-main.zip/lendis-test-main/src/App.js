import React, { createContext, useState } from 'react';

import Products from './pages/products';
import Checkout from './pages/checkout';

import Header from './layout/Header';
import Body from './layout/Body';
import Footer from './layout/Footer';
import { BrowserRouter as Router, Switch, Route  } from 'react-router-dom';
import ThemeProvider from './components/ThemeProvider';

export const CartContext = createContext(null);

const App = () => {

  const [items, setItems] = useState([]);
  function addItems(item) {
    let updatedItems = [...items];
    let index = updatedItems.findIndex((i)=> i.id === item.id)
    if( index >= 0) {
      updatedItems[index] = {
        ...item,
        count: updatedItems[index]["count"]+1
      }
    } else {
      updatedItems.push({
        ...item,
        count:1
      })
    }
    setItems(updatedItems);
  }
  function removeItems(item) {
    let updatedItems = [...items];
    let index = updatedItems.findIndex((i)=> i.id === item.id)
    if( index >= 0) {
      if(updatedItems[index]["count"] > 1) {
        updatedItems[index]["count"]--;
      } else {
        updatedItems.splice(index,1)
      }
    }
    setItems(updatedItems);
  }

  return (
    <CartContext.Provider
      value={{ items: items, addItems:addItems, removeItems: removeItems}}
    >
      <ThemeProvider>
      <Header />
      <Body>
        <Router>
        <Switch>
          <Route exact path="/" component={Products}/>
          <Route path="/checkout" component={Checkout}/>
        </Switch>
        </Router>

      </Body>
      <Footer />
      </ThemeProvider>

    </CartContext.Provider>
  );
};

export default App;
