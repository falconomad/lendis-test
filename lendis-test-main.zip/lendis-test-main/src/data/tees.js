/**
 * DO NOT CHANGE ME!
 */
export const tees =
  [
    {
      id: '5f4d4a7e62fb0224951e7ec4',
      name: 'sdsg',
      headline: 'with Tomato & Lemon',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 10,
    },
    {
      id: '5f4d4aa9f4508b34e9680613',
      name: 'Gouda Vibes Burgers',
      headline: 'with Tomato Onion Jam & Potato Wedges',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 8,
    },
    {
      id: '5f4d4acdab96be0cd6073022',
      name: 'Figgy Balsamic Pork',
      headline: 'with Roasted Carrots & Thyme Potatoes',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 9
    },
    {
      id: '5f4d4e62e85668628873add2',
      name: 'Sweet Soy Glazed Steak Tacos',
      slug: 'sweet-soy-glazed-steak-tacos',
      headline: 'with Spicy Slaw, Marinated Cucumber & Peanuts',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 20
    },
    {
      id: '5f4e82c04094d36cbf05dd61',
      name: 'Pork Sausage & Roasted Pepper Pasta',
      slug: 'pork-sausage-roasted-pepper-pasta',
      headline: 'with Creamy Parmesan Garlic Tomato Sauce',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 7
    },
    {
      id: '5f4d4e9b013bb224b742e2b1',
      name: 'Pork Flautas Supreme',
      slug: 'pork-flautas-supreme',
      headline: 'with Pico de Gallo & Lime Crema',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 9,
    },
    {
      id: '5f4d4ed9f57387323014001f',
      name: 'Jumpin\u2019 Jack Chicken Bowls',
      slug: 'jumpin-jack-chicken-bowls',
      headline: 'with Rice, Sour Cream & Lime',
      image:
        'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
        price: 15
    },
    {
      id: '5f4d5ce6a55a305b1724c789',
      name: 'Bruschetta Zucchini Boats',
      slug: 'bruschetta-zucchini-boats',
      headline: 'with Couscous & Melty Italian Cheeses',
      image:
        'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
        price: 25
    },
    {
      id: '5f4d5d1028b37d30f71cd7ba',
      name: 'Black Bean & Poblano Quesadillas',
      slug: 'black-bean-quesadillas',
      headline: 'with Salsa Fresca & Lime Sour Cream',
      image:
        'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
        price: 10,
    },
    {
      id: '5f4d5dc7d15bd31fc9024dac',
      name: 'Lemon Tortelloni Palermo',
      slug: 'lemon-tortelloni-palermo',
      headline: 'with Roasted Bell Pepper & Parmesan',
      image: 'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
      price: 10
    },
    {
      id: '5f4d5deaeb5aaa261c76c56c',
      name: 'Duck a l\u2019Orange',
      slug: 'duck-a-l-orange',
      headline: 'with Duck Fat Mashed Potatoes & Arugula Almond Salad',
      image:
        'https://5.imimg.com/data5/SH/GC/MY-8764775/mens-t-shirt-500x500.jpg',
        price: 10,
    },
    {
      id: '5f4d5f4ee85668628873add8',
      name: 'Steak & Shrimp in a Creamy Thyme Sauce',
      slug: 'steak-shrimp-in-a-creamy-thyme-sauce',
      headline: 'with Zesty Roasted Green Beans & Crispy-Onion-Topped Mashed Potatoes',
      image:
        'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
        price: 10,
    },
    {
      id: '5f4d5f6ad15bd31fc9024dae',
      name: 'Chicken Katsu',
      slug: 'chicken-katsu',
      headline: 'with Roasted Green Beans & Ginger Rice',
      image:
        'https://5.imimg.com/data5/KD/VI/MY-34278/mens-printed-t-shirt-500x500.jpg',
        price: 10,
    },
    {
      id: '5f4d5fb78cbc28156118f6e8',
      name: 'men tank top',
      slug: 'men tank top',
      headline: 'men tank top',
      image:
        'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
        price: 12,
    },
    {
      id: '5f4d6197a096ba0ab134cc47',
      name: 'Unisex Cotton Men Office T Shirt',
      slug: 'Unisex Cotton Men Office T Shirt',
      headline: 'Unisex Cotton Men Office T Shirt',
      image:'https://5.imimg.com/data5/GO/FK/RS/ANDROID-81893637/product-jpeg-500x500.jpg',
      price: 13,
    },
    {
      id: '5f4eb0f632b8724352209946',
      name: 'Round Half Sleeve Mens Cotton T Shirt, Size: S - Xxl, Quantity Per Pack: 1',
      slug: 'Round Half Sleeve Mens Cotton T Shirt, Size: S - Xxl, Quantity Per Pack: 1',
      headline: 'Round Half Sleeve Mens Cotton T Shirt, Size: S - Xxl, Quantity Per Pack: 1',
      image:
        'https://5.imimg.com/data5/SELLER/Default/2021/6/AM/HJ/IZ/17988471/mens-cotton-t-shirt-500x500.png',
        price: 18
    },
  ]
