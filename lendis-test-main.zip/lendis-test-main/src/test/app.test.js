// import { waitFor} from '@testing-library/dom';
import { act, render, } from '@testing-library/react';
import { fireEvent, screen,onClick } from "@testing-library/dom";

import React from 'react';
import { BrowserRouter } from 'react-router-dom';
// import { act, render, waitFor } from '@testing-library/react';
import App from '../App';


test('app renders without crashing', async () => {
  await act(async () => {
      render(
        <BrowserRouter>
          <App/>
        </BrowserRouter>
    );
  });
  expect(screen.getByText("Choose your Tees!")).toBeInTheDocument();

});
