import React from "react";

import { render } from "@testing-library/react";
import { fireEvent, screen,onClick } from "@testing-library/dom";

import App from "../App";
import { BrowserRouter } from "react-router-dom";
import { tees } from "../data/tees";

function renderApp() {
  return render(
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}


test("Item card add,remove and checkout", () => {
  const item1 = {
    id: '5f4d4aa9f4508b34e9680613',
    name: 'Gouda Vibes Burgers',
    headline: 'with Tomato Onion Jam & Potato Wedges',
    image:
      'https://5.imimg.com/data5/HA/MA/AL/SELLER-40281611/men-tank-top-500x500.jpg',
      price: 8,
  };
  const item2 = {
    id: '5f4d4ed9f57387323014001f',
    name: 'Jumpin\u2019 Jack Chicken Bowls',
    slug: 'jumpin-jack-chicken-bowls',
    headline: 'with Rice, Sour Cream & Lime',
    image:
      'https://5.imimg.com/data5/KE/MJ/MY-3749501/cotton-t-shirts-500x500.jpg',
      price: 15
  };
  renderApp();
  expect(screen.getByText(tees[0].name)).toBeInTheDocument();

  const buttonOne = screen.getByTestId(`add-${item1.id}`);
  const buttonTwo = screen.getByTestId(`add-${item2.id}`);


  fireEvent.click(buttonOne);
  fireEvent.click(buttonTwo);


  const openCartButton = screen.getByTestId("open-cart");

  fireEvent.click(openCartButton);
  expect(screen.getByTestId("cart-items-total").textContent).toBe('No of Items :  2');

  const removeButton = screen.getByTestId(`remove-${item1.id}`);
  fireEvent.click(removeButton);

  expect(screen.getByTestId("cart-items-total").textContent).toBe('No of Items :  1');

  const checkoutButton = screen.getByTestId("checkout-button");
  fireEvent.click(checkoutButton);

  jest.setTimeout(200);

  expect(window.location.pathname).toBe("/checkout");
  expect(screen.getByText("Total")).toBeInTheDocument();
  const removeButtonCheckout = screen.getByTestId(`checkout-remove-${item2.id}`);
  fireEvent.click(removeButtonCheckout);
  expect(screen.getByTestId("total-price").textContent).toBe(`${0}$`);
});
