import React from "react";

import { render } from "@testing-library/react";
import { fireEvent, screen,onClick } from "@testing-library/dom";

import { CartContext } from "../App";
import Products from "../pages/products";
import { tees } from "../data/tees";

function renderProductsList(value) {
  return render(
    <CartContext.Provider value={value}>
      <Products />
    </CartContext.Provider>
  );
}

test("Products listed properly", () => {
  const context = { items: [] };
  renderProductsList(context);
  expect(screen.getByText("Figgy Balsamic Pork")).toBeInTheDocument();

});
