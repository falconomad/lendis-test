// import { waitFor} from '@testing-library/dom';
import { act, render, } from '@testing-library/react';
import React from 'react';
import { BrowserRouter } from 'react-router-dom';
// import { act, render, waitFor } from '@testing-library/react';
import App from '../App';


test('renders without crashing', async () => {
  await act(async () => {
      render(
        <BrowserRouter>
          <App/>
        </BrowserRouter>
    );
  });
});
