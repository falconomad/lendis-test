import styled from 'styled-components';

const Body = styled.main`
  min-height: 100vh;
`;

export default Body;
