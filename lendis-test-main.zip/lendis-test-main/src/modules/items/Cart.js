import React, { useContext } from 'react';
import Box from '../../components/Box';
import Flex from '../../components/Flex';
import Text from '../../components/Text';
import Button from '../../components/Button';
import { CartContext } from '../../App';
import { useHistory } from 'react-router-dom';

const Cart = () => {
  const { items, removeItems } = useContext(
    CartContext
  );
  const history = useHistory();

  const handleCheckout = () => {
    history.push('/checkout')
  }

  return (
    <Box width={['290px', '450px']} padding={"md"}>
       <Flex justifyContent={"space-between"} paddingBottom={"sm"}>
        <Text data-testid={"cart-items-total"} textAlign="center" fontFamily="secondary" fontSize="sm">
             No of Items :  {items.length}
        </Text>
      </Flex>
      <Box>
        {
          items.map((element)=> {
            return <Flex key={element.id}justifyContent={"space-between"} paddingBottom={5}>
              <span>
                {element.name} * {element.count}
              </span>
              <Button data-testid={`remove-${element.id}`}variant={"warn"} onClick={()=> removeItems(element)}>
                Remove
              </Button>
            </Flex>
          })
        }
      </Box>
    <Flex justifyContent={"space-between"} borderTopStyle={"solid"} paddingTop={"sm"} borderTopWidth={"sm"} borderTopColor={"neutral_400"}>
      <Button data-testid={"checkout-button"} disabled={items.length === 0} variant={"primary"} onClick={()=> handleCheckout()}>
        Checkout
      </Button>
    </Flex>
  </Box>
  );
};

export default Cart;
