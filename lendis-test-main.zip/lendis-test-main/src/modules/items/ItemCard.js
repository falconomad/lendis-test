import React, { useContext } from 'react';
import PropTypes from 'prop-types';

import Flex from '../../components/Flex';
import Box from '../../components/Box';
import Text from '../../components/Text';
import Button from '../../components/Button';
import { CartContext } from '../../App';

const ItemCard = ({
  name,
  selected,
  item,
  handleAddItem,
}) => {

  return <Box
    padding={5}
    borderWidth={selected ? 'md' : null}
    borderStyle={selected ? 'solid' : null}
    borderColor={selected ? 'primary_600' : null}
    m={selected ? '-2px' : null}
    borderRadius="md"
    boxShadow="lg">
    <Box borderRadius="2px 2px 0px 0px" paddingBottom="56.25%" overflow="hidden" height="0">
      <img src={item.image} alt={name} width="100%" />
    </Box>

    <Flex justifyContent={"center"}>
      <Text fontWeight="bold" fontFamily="primary" fontSize="md">
        {item.name}
      </Text>
    </Flex>
    <Flex justifyContent={"center"}>
      <Button data-testid={`add-${item.id}`} variant={"primary"}  onClick={()=> handleAddItem(item) }>
        {"Add To Cart"}
      </Button>
    </Flex>

  </Box>
};

ItemCard.propTypes = {
  handleAddItem: PropTypes.func,
  handleRemoveItem: PropTypes.func,
  id: PropTypes.string,
  image: PropTypes.string,
};



export default ItemCard;


