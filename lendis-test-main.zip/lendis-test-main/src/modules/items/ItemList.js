import React, { useContext } from 'react';

import { Row, Col } from '../../components/Grid';
import Flex from '../../components/Flex';
import Box from '../../components/Box';
import ItemCard from './ItemCard';
import PriceInfo from './PriceInfo';
import { tees } from '../../data/tees';
import { CartContext } from '../../App';


const ItemList = () => {
  const { addItems, removeItems } = useContext(
    CartContext
  );

  const handleAddItem = (item) => {
    addItems(item)
  }
  const handleRemoveItem = (item) => {
    removeItems(item)
  };

  return (
    <>
      <Row>
        <Col sm={6}>
          <Flex alignItems="center" justifyContent="flex-end">
            <Box textAlign="right" mr="xs">
              <h3>Open cart</h3>
            </Box>
            <PriceInfo />
          </Flex>
        </Col>
      </Row>
      <Row>
        {tees.map((item) => (
          <Col sm={12} md={6} xl={4} key={item.id}>
            <Box mb="md">
              <ItemCard
                item={item}
                handleAddItem={handleAddItem}
                handleRemoveItem={handleRemoveItem}
              />
            </Box>
          </Col>
        ))}
      </Row>
    </>
  );
};

export default ItemList;
